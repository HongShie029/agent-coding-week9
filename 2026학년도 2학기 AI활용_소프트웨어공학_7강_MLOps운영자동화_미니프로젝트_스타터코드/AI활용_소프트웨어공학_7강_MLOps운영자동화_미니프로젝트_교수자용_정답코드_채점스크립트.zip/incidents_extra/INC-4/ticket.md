# INC-4 고객센터 접수

**제목:** 서버가 주기적으로 재시작되고 응답이 느리다

10시 이후 API 서버가 25분 간격으로 재시작되고 있고 지연이 커집니다. 10시에 모델 v13 서비스 배포가 있었습니다.

> 이 번들의 파일: ticket.md · alerts.json · deploys.json · metrics.csv · logs.jsonl
