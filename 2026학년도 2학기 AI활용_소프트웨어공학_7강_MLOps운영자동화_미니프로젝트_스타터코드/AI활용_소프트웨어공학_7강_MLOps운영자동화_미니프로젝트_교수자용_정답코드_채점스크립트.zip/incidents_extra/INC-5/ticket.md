# INC-5 고객센터 접수

**제목:** 쿠폰 적용 주문이 실패한다

16시경부터 쿠폰을 적용한 주문만 오류가 납니다. 쿠폰 없는 주문은 정상입니다. 15시 50분에 v1.5.2 배포가 있었습니다.

> 이 번들의 파일: ticket.md · alerts.json · deploys.json · metrics.csv · logs.jsonl
