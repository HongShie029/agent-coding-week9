// 숨은 평가 세트 (교수자용, 학생에게 배포 금지)
const fs = require("fs"), path = require("path");
const { norm } = require("../../solution/sim/drift");

const alerts = [
  { id: "HA01-normal_day", seed: 111, startMinuteOfDay: 360, events: [], expect: "none", title: "평범한 하루(다른 시작 시각)" },
  { id: "HA02-flash_sale_night", seed: 112, startMinuteOfDay: 0, events: [{ type: "traffic", start: 1000, end: 1050, value: 4, ramp: 3 }, { type: "p95mult", start: 1000, end: 1050, value: 1.25, ramp: 3 }], expect: "none", title: "타임세일 4배" },
  { id: "HA03-double_blip", seed: 113, startMinuteOfDay: 0, events: [{ type: "err", start: 400, end: 403, value: 0.12 }, { type: "err", start: 420, end: 423, value: 0.12 }], expect: "none", title: "일시 오류 급증 2회" },
  { id: "HA04-bad_deploy_night", seed: 114, startMinuteOfDay: 0, events: [{ type: "err", start: 150, end: 200, value: 0.05 }], expect: "page", incident: { start: 150, end: 200 }, sla: 5, title: "새벽 배포 직후 오류율 급등(트래픽 적음)" },
  { id: "HA05-latency_creep", seed: 115, startMinuteOfDay: 0, events: [{ type: "p95", start: 900, end: 1000, value: 700, ramp: 50 }], expect: "page", incident: { start: 900, end: 1000 }, sla: 25, title: "지연이 서서히 증가" },
  { id: "HA06-slow_burn", seed: 116, startMinuteOfDay: 0, events: [{ type: "err", start: 300, end: 390, value: 0.016 }], expect: "page", incident: { start: 300, end: 390 }, sla: 20, title: "오류율이 2%로 계속 유지(느린 소진)" },
  { id: "HA07-traffic_dip", seed: 117, startMinuteOfDay: 0, events: [{ type: "traffic", start: 800, end: 860, value: 0.35 }], expect: "page", incident: { start: 800, end: 860 }, sla: 10, title: "요청이 평소의 35%로 급감(조용한 장애)" },
  { id: "HA08-pay_outage", seed: 118, startMinuteOfDay: 0, events: [{ type: "payFail", start: 500, end: 550, value: 0.35 }], expect: "page", incident: { start: 500, end: 550 }, sla: 10, title: "결제 실패율 급등(전체 오류율은 정상)" },
  { id: "HA09-ctr_drop", seed: 119, startMinuteOfDay: 0, events: [{ type: "ctr", start: 400, end: 520, value: 0.5 }], expect: "any", incident: { start: 400, end: 520 }, sla: 60, hard: true, title: "추천 클릭률이 절반으로(오류 없는 품질 저하)" },
  { id: "HA10-normal_day", seed: 120, startMinuteOfDay: 720, events: [], expect: "none", title: "평범한 하루(다른 시드)" },
  { id: "HA11-small_regression", seed: 121, startMinuteOfDay: 0, events: [{ type: "err", start: 1000, end: 1060, value: 0.02 }], expect: "page", incident: { start: 1000, end: 1060 }, sla: 20, title: "오류율 +2%p 지속" },
  { id: "HA12-error_ramp", seed: 122, startMinuteOfDay: 0, events: [{ type: "err", start: 600, end: 660, value: 0.06, ramp: 10 }], expect: "page", incident: { start: 600, end: 660 }, sla: 10, title: "오류율이 10분에 걸쳐 증가" },
];

const T1 = norm([0.18, 0.15, 0.14, 0.30, 0.13, 0.10]), T2 = norm([0.12, 0.12, 0.30, 0.16, 0.18, 0.12]);
const drift = [
  { id: "HD1-stable", seed: 131, days: 60, events: [], expectKind: "none", title: "안정(주말 계절성)" },
  { id: "HD2-sudden", seed: 132, days: 60, events: [{ type: "cat", start: 25, ramp: 0, target: T2 }], expectKind: "covariate", onset: 25, sla: 3, title: "구성 급변" },
  { id: "HD3-gradual", seed: 133, days: 60, events: [{ type: "cat", start: 15, ramp: 20, target: T1 }], expectKind: "covariate", onset: 15, sla: 14, title: "서서히 변화" },
  { id: "HD4-data_break", seed: 134, days: 60, events: [{ type: "dq", start: 30, nullRate: 0.15, zeroPrice: 0.40 }], expectKind: "data_quality", onset: 30, sla: 2, title: "ETL 변경으로 결측 급증" },
  { id: "HD5-low_volume_run", seed: 135, days: 60, events: [], lowVolumeDays: [10, 11, 12, 33], expectKind: "none", title: "요청이 적은 날이 연속" },
  { id: "HD6-zero_price", seed: 136, days: 60, events: [{ type: "dq", start: 22, nullRate: 0.02, zeroPrice: 0.25 }], expectKind: "data_quality", onset: 22, sla: 2, hard: true, title: "결측은 적지만 0원 가격이 급증" },
  { id: "HD7-weekend_shift", seed: 137, days: 60, events: [{ type: "cat", start: 26, ramp: 0, target: T2 }], expectKind: "covariate", onset: 26, sla: 3, title: "토요일에 시작된 변화(주말 계절성과 겹침)" },
  { id: "HD8-shift_on_low_days", seed: 138, days: 60, events: [{ type: "cat", start: 20, ramp: 0, target: T1 }], lowVolumeDays: [20, 21], expectKind: "covariate", onset: 20, sla: 5, hard: true, title: "변화 시작일에 요청이 거의 없음" },
];

const rollouts = [
  { id: "HR01-good", seed: 141, startMinuteOfDay: 600, events: [], bad: false, expect: "complete", title: "정상 릴리스" },
  { id: "HR02-err_spike_night", seed: 142, startMinuteOfDay: 180, events: [{ type: "err", arm: "canary", start: 0, end: 999, value: 0.07 }], bad: true, badFrom: 0, expect: "rollback", exposureFull: 100, exposureHalf: 250, title: "새벽(트래픽 적음) 오류 릴리스" },
  { id: "HR03-latency", seed: 143, startMinuteOfDay: 840, events: [{ type: "p95mult", arm: "canary", start: 0, end: 999, value: 1.5 }], bad: true, badFrom: 0, expect: "rollback", exposureFull: 100, exposureHalf: 250, title: "지연 1.5배 릴리스" },
  { id: "HR04-transient", seed: 144, startMinuteOfDay: 840, events: [{ type: "err", arm: "canary", start: 5, end: 7, value: 0.12 }], bad: false, expect: "complete", title: "정상 릴리스, 카나리에서 2분 튐" },
  { id: "HR05-upstream_p95", seed: 145, startMinuteOfDay: 840, events: [{ type: "p95", arm: "both", start: 2, end: 9, value: 500 }], bad: false, expect: "complete", title: "외부 요인으로 두 갈래 모두 느려짐" },
  { id: "HR06-silent_quality", seed: 146, startMinuteOfDay: 840, events: [{ type: "ctr", arm: "canary", start: 0, end: 999, value: 0.6 }], bad: true, badFrom: 0, expect: "rollback", exposureFull: 300, exposureHalf: 600, hard: true, title: "오류 없이 추천 클릭률만 하락" },
  { id: "HR07-payment_only", seed: 147, startMinuteOfDay: 840, events: [{ type: "payFail", arm: "canary", start: 0, end: 999, value: 0.30 }], bad: true, badFrom: 0, expect: "rollback", exposureFull: 100, exposureHalf: 250, hard: true, title: "결제 경로만 실패(전체 오류율은 정상)" },
  { id: "HR08-slow_leak", seed: 148, startMinuteOfDay: 840, events: [{ type: "p95", arm: "canary", start: 12, end: 999, value: 600, ramp: 25 }], bad: true, badFrom: 12, expect: "rollback", exposureFull: 250, exposureHalf: 500, title: "배포 12분 후부터 지연이 커짐" },
  { id: "HR09-err_small", seed: 149, startMinuteOfDay: 840, events: [{ type: "err", arm: "canary", start: 0, end: 999, value: 0.02 }], bad: true, badFrom: 0, expect: "rollback", exposureFull: 200, exposureHalf: 450, title: "오류율 +2%p(작은 회귀)" },
  { id: "HR10-good_night", seed: 150, startMinuteOfDay: 180, events: [], bad: false, expect: "complete", title: "새벽 정상 릴리스(표본 적음)" },
  { id: "HR11-late_error", seed: 151, startMinuteOfDay: 840, events: [{ type: "err", arm: "canary", start: 14, end: 999, value: 0.05 }], bad: true, badFrom: 14, expect: "rollback", exposureFull: 150, exposureHalf: 350, title: "25% 단계에서 오류 시작" },
];

const here = __dirname;
const changes = JSON.parse(fs.readFileSync(path.join(here, "changes.json"), "utf8"));
const cases = JSON.parse(fs.readFileSync(path.join(here, "cases.json"), "utf8"));
module.exports = { alerts, drift, rollouts, changes, cases };
