// 인시던트 번들 생성기 (교수자용). 사용: node gen/incidents.js <type> <outDir> [seed]
// type: config_change | data_quality | external_dependency | resource_leak | code_regression
const fs = require("fs"), path = require("path");
const { rngFor } = require("../solution/sim/rng");
const { sampleAt } = require("../solution/sim/engine");

const hhmm = (m) => `${String(Math.floor(m / 60) % 24).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
const mm = (s) => { const [h, m] = s.split(":").map(Number); return h * 60 + m; };

const SPECS = {
  config_change: {
    id: "INC-1", start: "13:00", minutes: 150,
    title: "주문 목록 조회가 느리고 오류가 난다",
    ticket: "14시 20분경부터 고객센터에 '주문 내역이 안 열린다', '결제 후 주문 확인 오류' 문의가 급증했습니다. 14시 10분에 v1.4.0 배포가 있었습니다.",
    deploys: [
      { id: "DEP-1038", ts: "11:30", kind: "deploy", svc: "web", version: "v1.3.9", changes: ["배너 문구 수정"] },
      { id: "DEP-1042", ts: "14:10", kind: "deploy", svc: "api", version: "v1.4.0", changes: ["주문 목록 조회 필터 개선", "환경 변수 정리: DB_POOL_SIZE 20 → 5", "lodash 4.17.20 → 4.17.21"] },
    ],
    onset: "14:16", rootCause: "config_change", change: "DEP-1042",
    keyLines: [["14:10", "INFO", "api", "release v1.4.0 started: env DB_POOL_SIZE=5 (previous 20)"], ["14:16", "ERROR", "api", "db pool exhausted: 5/5 connections in use (db=orders), waiting=37"], ["14:17", "ERROR", "api", "TimeoutError: acquiring connection timed out after 3000ms (GET /orders)"], ["14:19", "ERROR", "api", "db pool exhausted: 5/5 connections in use (db=orders), waiting=88"], ["14:25", "ERROR", "api", "TimeoutError: acquiring connection timed out after 3000ms (POST /orders)"]],
    herrings: [["13:05", "WARN", "cache", "cache miss ratio 0.41 above 0.30 (key=product:list)"], ["13:40", "WARN", "cache", "cache miss ratio 0.43 above 0.30 (key=product:list)"], ["14:02", "WARN", "api", "DeprecationWarning: legacy endpoint /v1/cart will be removed"], ["14:30", "WARN", "api", "DeprecationWarning: legacy endpoint /v1/cart will be removed"]],
    actions: [["rollback", "revert_config"], ["add_gate", "add_alert"]],
  },
  data_quality: {
    id: "INC-2", start: "01:00", minutes: 300,
    title: "추천 상품 클릭이 갑자기 줄었다",
    ticket: "오전 4시 이후 추천 영역 클릭률이 평소의 절반 수준입니다. 서버 오류는 없습니다. 새벽에 정기 재학습과 모델 교체(v12)가 있었습니다.",
    deploys: [
      { id: "ETL-318", ts: "02:00", kind: "etl", svc: "data-pipeline", version: "job-318", changes: ["상류 주문 스키마 변경 반영: price 컬럼 기본값 처리"] },
      { id: "DEP-M503", ts: "03:30", kind: "model", svc: "recommender-train", version: "v12-train", changes: ["야간 정기 재학습 (데이터: 최근 30일)"] },
      { id: "DEP-M504", ts: "04:10", kind: "model", svc: "recommender", version: "v12", changes: ["모델 v12 운영 반영 (v11 → v12)"] },
    ],
    onset: "04:15", rootCause: "data_quality", change: "ETL-318",
    keyLines: [["02:03", "WARN", "etl", "ETL-318: column price null -> 0 (rows=48210)"], ["03:31", "WARN", "train", "feature price: null_rate 0.00 but zero_rate 0.31 (previous 0.05)"], ["04:15", "INFO", "rec", "ctr(5m) 0.043 vs 7d avg 0.080"]],
    herrings: [["03:42", "INFO", "train", "eval hitRate=0.31 OK (gate passed)"], ["04:10", "INFO", "deploy", "model v12 promoted to production"], ["02:30", "WARN", "db", "slow query 1.2s (orders_by_user)"]],
    actions: [["fix_data_pipeline"], ["rollback"]],
  },
  external_dependency: {
    id: "INC-3", start: "18:00", minutes: 180,
    title: "결제가 계속 실패한다는 문의",
    ticket: "19시 20분경부터 결제 실패 문의가 늘었습니다. 18시 40분에 이미지 리사이즈 서비스 배포가 있었습니다.",
    deploys: [{ id: "DEP-1050", ts: "18:40", kind: "deploy", svc: "image-resizer", version: "v2.1.0", changes: ["썸네일 생성 최적화"] }],
    onset: "19:20", rootCause: "external_dependency", change: null,
    keyLines: [["19:20", "ERROR", "payment", "pg timeout after 5000ms provider=PG-A (order=O-88121)"], ["19:22", "ERROR", "payment", "pg timeout after 5000ms provider=PG-A (order=O-88130)"], ["19:25", "INFO", "payment", "provider status page: PG-A degraded performance (incident #2291)"], ["19:40", "ERROR", "payment", "pg timeout after 5000ms provider=PG-A retries=3"]],
    herrings: [["18:41", "INFO", "deploy", "image-resizer v2.1.0 rolled out"], ["18:55", "WARN", "image", "resize queue lag 4.1s"], ["19:05", "WARN", "image", "resize queue lag 5.3s"]],
    actions: [["failover_dependency", "add_circuit_breaker"], ["add_alert"]],
  },
  resource_leak: {
    id: "INC-4", start: "09:30", minutes: 150,
    title: "서버가 주기적으로 재시작되고 응답이 느리다",
    ticket: "10시 이후 API 서버가 25분 간격으로 재시작되고 있고 지연이 커집니다. 10시에 모델 v13 서비스 배포가 있었습니다.",
    deploys: [{ id: "DEP-1061", ts: "10:00", kind: "deploy", svc: "recommender", version: "v13", changes: ["모델 v13 적용", "모델 로딩 방식 변경(워밍업 시 사전 로드)"] }],
    onset: "10:40", rootCause: "resource_leak", change: "DEP-1061",
    keyLines: [["10:12", "INFO", "rec", "model v13 loaded (2 copies resident: warmup + serving), rss=2.9GB"], ["10:35", "WARN", "api", "memory usage 91% (limit 3.0GB)"], ["10:55", "ERROR", "api", "OOMKilled: container api-3 restarted (restartCount=1)"], ["11:20", "ERROR", "api", "OOMKilled: container api-3 restarted (restartCount=2)"]],
    herrings: [["09:50", "WARN", "api", "DeprecationWarning: legacy endpoint /v1/cart will be removed"], ["10:20", "WARN", "cache", "cache miss ratio 0.35 above 0.30 (key=product:list)"]],
    actions: [["rollback", "restart_service"], ["add_alert", "add_gate"]],
  },
  code_regression: {
    id: "INC-5", start: "15:00", minutes: 120,
    title: "쿠폰 적용 주문이 실패한다",
    ticket: "16시경부터 쿠폰을 적용한 주문만 오류가 납니다. 쿠폰 없는 주문은 정상입니다. 15시 50분에 v1.5.2 배포가 있었습니다.",
    deploys: [{ id: "DEP-1070", ts: "15:50", kind: "deploy", svc: "api", version: "v1.5.2", changes: ["쿠폰 할인 계산 리팩터링"] }, { id: "DEP-1069", ts: "15:20", kind: "deploy", svc: "coupon-service", version: "v3.2", changes: ["응답 필드 추가"] }],
    onset: "15:52", rootCause: "code_regression", change: "DEP-1070",
    keyLines: [["15:52", "ERROR", "api", "TypeError: Cannot read properties of undefined (reading 'discount') at applyCoupon (order.js:88)"], ["15:58", "ERROR", "api", "TypeError: Cannot read properties of undefined (reading 'discount') at applyCoupon (order.js:88)"], ["16:10", "ERROR", "api", "TypeError: Cannot read properties of undefined (reading 'discount') at applyCoupon (order.js:88)"]],
    herrings: [["15:21", "WARN", "coupon", "coupon-service latency 380ms above 300ms"], ["15:40", "WARN", "coupon", "coupon-service latency 410ms above 300ms"]],
    actions: [["rollback"], ["add_gate"]],
  },
};

function build(type, outDir, seed = 5) {
  const sp = SPECS[type]; const start = mm(sp.start);
  const r = rngFor(seed, sp.id.length, 3);
  const lines = [];
  const add = (ts, level, svc, msg, tag) => lines.push({ m: mm(ts), ts, level, svc, msg, tag });
  // 평소 로그(잡음)
  for (let m = 0; m < sp.minutes; m += 1 + Math.floor(r() * 2)) {
    const ts = hhmm(start + m);
    const roll = r();
    if (roll < 0.55) add(ts, "INFO", "api", `GET /products 200 ${60 + Math.floor(r() * 120)}ms`);
    else if (roll < 0.8) add(ts, "INFO", "api", `POST /cart/items 200 ${40 + Math.floor(r() * 90)}ms`);
    else if (roll < 0.9) add(ts, "INFO", "health", "healthcheck ok instances=4/4");
    else add(ts, "INFO", "order", `order created id=O-${88000 + Math.floor(r() * 900)} amount=${(10 + Math.floor(r() * 80)) * 1000}`);
  }
  for (const d of sp.deploys) add(d.ts, "INFO", "deploy", `${d.id} ${d.svc} ${d.version} applied (${d.kind})`, "deploy");
  sp.keyLines.forEach(([t, l, s, msg]) => add(t, l, s, msg, "key"));
  sp.herrings.forEach(([t, l, s, msg]) => add(t, l, s, msg, "rh"));
  // 사고 이후 반복되는 오류 로그(핵심 신호의 반복): 같은 종류의 key 줄을 몇 번 더 만든다
  const onsetM = mm(sp.onset);
  const repeatBase = sp.keyLines.filter((k) => mm(k[0]) >= onsetM && k[1] === "ERROR");
  for (let i = 0; i < 30 && repeatBase.length; i++) {
    const b = repeatBase[i % repeatBase.length];
    add(hhmm(Math.min(start + sp.minutes - 1, onsetM + 2 + i * 2)), "ERROR", b[2], b[3], "key");
  }
  lines.sort((a, b) => a.m - b.m || (a.tag ? 1 : 0) - (b.tag ? 1 : 0));
  const out = lines.map((x, i) => ({ id: "L" + String(i + 1).padStart(4, "0"), ts: x.ts, level: x.level, svc: x.svc, msg: x.msg, _tag: x.tag }));
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "logs.jsonl"), out.map((x) => JSON.stringify({ id: x.id, ts: x.ts, level: x.level, svc: x.svc, msg: x.msg })).join("\n") + "\n");
  // 지표
  const evs = buildEvents(type, sp, start);
  const rows = ["time,requests,errors,p95Ms,paymentAttempts,paymentFails,recImpr,recClicks"];
  for (let m = 0; m < sp.minutes; m++) {
    const s = sampleAt({ seed: 900 + seed, t: m, startMinuteOfDay: start, events: evs });
    rows.push([hhmm(start + m), s.requests, s.errors, s.p95Ms, s.paymentAttempts, s.paymentFails, s.recImpr, s.recClicks].join(","));
  }
  fs.writeFileSync(path.join(outDir, "metrics.csv"), rows.join("\n") + "\n");
  fs.writeFileSync(path.join(outDir, "deploys.json"), JSON.stringify(sp.deploys, null, 2) + "\n");
  const alerts = buildAlerts(type, sp);
  fs.writeFileSync(path.join(outDir, "alerts.json"), JSON.stringify(alerts, null, 2) + "\n");
  fs.writeFileSync(path.join(outDir, "ticket.md"), `# ${sp.id} 고객센터 접수\n\n**제목:** ${sp.title}\n\n${sp.ticket}\n\n> 이 번들의 파일: ticket.md · alerts.json · deploys.json · metrics.csv · logs.jsonl\n`);
  const key = {
    incident: sp.id, rootCause: sp.rootCause, change: sp.change, firstBadTime: sp.onset,
    evidenceIds: out.filter((x) => x._tag === "key").map((x) => x.id), herringIds: out.filter((x) => x._tag === "rh").map((x) => x.id),
    requiredActionGroups: sp.actions,
  };
  return key;
}
// 지표 이벤트를 사건 시각에 맞춰 만든다 (분 단위, 번들 시작 기준)
function buildEvents(type, sp, start) {
  const o = mm(sp.onset) - start;
  const E = {
    config_change: [{ type: "err", start: o, end: 999, value: 0.09, ramp: 8 }, { type: "p95", start: o, end: 999, value: 900, ramp: 8 }],
    data_quality: [{ type: "ctr", start: o, end: 999, value: 0.5, ramp: 5 }],
    external_dependency: [{ type: "payFail", start: o, end: o + 70, value: 0.40 }, { type: "p95", start: o, end: o + 70, value: 250 }],
    resource_leak: [{ type: "p95", start: o, end: 999, value: 500, ramp: 40 }, { type: "err", start: o + 15, end: 999, value: 0.04, ramp: 20 }],
    code_regression: [{ type: "err", start: o, end: 999, value: 0.05 }],
  };
  return E[type];
}
function buildAlerts(type, sp) {
  const o = mm(sp.onset);
  const A = {
    config_change: [[o + 6, "error-sustained", "page", "오류율 6.1% (4분 연속)"], [o + 9, "latency-high", "page", "p95 702ms (3분 연속)"]],
    data_quality: [[o + 55, "rec-ctr-drop", "ticket", "추천 클릭률 0.043 (30분 합산)"]],
    external_dependency: [[o + 12, "payment-fail-rate", "page", "결제 실패율 38% (10분)"]],
    resource_leak: [[o + 22, "latency-high", "page", "p95 780ms (3분 연속)"]],
    code_regression: [[o + 5, "error-sustained", "page", "오류율 5.4% (4분 연속)"]],
  }[type];
  return A.map(([m, rule, severity, detail]) => ({ ts: hhmm(m), rule, severity, detail }));
}
module.exports = { build, SPECS };
if (require.main === module) {
  const [type, out, seed] = process.argv.slice(2);
  const key = build(type, out, seed ? Number(seed) : 5);
  console.log(JSON.stringify(key, null, 2));
}
