#!/usr/bin/env node
// 7강 자동 채점 보조 도구 (교수자용)
// 사용: node grade/grade.js <학생프로젝트폴더> [--json] [--extra-incidents]
//   원본 폴더는 수정하지 않는다. 임시 폴더에서 평가기(sim, lib, scripts 등)를 원본으로 복원한 뒤 숨은 시나리오로 평가한다.
const fs = require("fs"), os = require("os"), path = require("path"), crypto = require("crypto");
const { spawnSync } = require("child_process");

const argv = process.argv.slice(2);
const studentDir = argv.find((a) => !a.startsWith("--"));
if (!studentDir || !fs.existsSync(studentDir)) { console.error("사용: node grade/grade.js <학생프로젝트폴더> [--json]"); process.exit(1); }
const asJson = argv.includes("--json");
const SOL = path.resolve(__dirname, "..", "solution");
const log = (...a) => { if (!asJson) console.error(...a); };

const SKIP = new Set(["node_modules", ".git", "reports"]);
function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    e.isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d);
  }
}
const treeHash = (dir) => {
  const h = crypto.createHash("sha1");
  const walk = (d) => { if (!fs.existsSync(d)) return; for (const e of fs.readdirSync(d, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { h.update(p.slice(dir.length)); h.update(fs.readFileSync(p)); } } };
  walk(dir); return h.digest("hex");
};

// 1) 임시 폴더에 복사하고 보호 대상(평가기·시뮬레이터·샘플)을 원본으로 복원
const root = fs.mkdtempSync(path.join(os.tmpdir(), "g7-"));
copyDir(path.resolve(studentDir), root);
const notes = [];
for (const d of ["sim", "lib", "src", "config", "ai_ops", "incidents", "changes", "mlops/cases"]) {
  const mine = path.join(root, d), orig = path.join(SOL, d);
  if (treeHash(mine) !== treeHash(orig)) notes.push(`${d}/ 가 원본과 다름(원본으로 복원하여 채점)`);
  fs.rmSync(mine, { recursive: true, force: true }); fs.cpSync(orig, mine, { recursive: true });
}
for (const f of fs.readdirSync(path.join(SOL, "scripts"))) {
  if (f === "ops-ci.js") continue;
  const a = path.join(root, "scripts", f), b = path.join(SOL, "scripts", f);
  if (!fs.existsSync(a) || fs.readFileSync(a, "utf8") !== fs.readFileSync(b, "utf8")) notes.push(`scripts/${f} 가 원본과 다름(복원)`);
  fs.copyFileSync(b, a);
}

// 2) 영역별 평가 (자식 프로세스, 시간 제한)
const KEYS = { pipeline: "파이프라인 게이트", alerts: "알림 규칙", policy: "MLOps 정책", rollout: "점진 배포" };
function evalOne(key, set, dir) {
  const r = spawnSync(process.execPath, [path.join(__dirname, "eval_child.js"), root, key, set, dir || "-"], { encoding: "utf8", timeout: 120000, maxBuffer: 1 << 26 });
  if (r.error || r.status !== 0) return { name: KEYS[key], score: 0, items: [], error: r.error ? "시간 초과 또는 실행 실패" : (r.stderr || "").split("\n")[0] };
  try { return JSON.parse(r.stdout); } catch { return { name: KEYS[key], score: 0, items: [], error: "결과 해석 실패" }; }
}
const R = { student: path.resolve(studentDir), notes, hidden: {}, public: {}, score: {} };
let aTotal = 0, hardItems = [];
for (const k of Object.keys(KEYS)) {
  log(`평가 중: ${KEYS[k]} …`);
  const h = evalOne(k, "hidden"), p = evalOne(k, "public");
  R.hidden[k] = h; R.public[k] = { score: p.score, error: p.error };
  R.score["A_" + k] = Math.round(h.score * 10 * 100) / 100;
  aTotal += h.score * 10;
  if (h.score >= 0.5) hardItems.push(...(h.items || []).filter((i) => i.hard));   // 해당 영역이 50% 이상일 때만 도전 점수를 인정
}
R.score.A_total = Math.round(aTotal * 100) / 100;
const allHard = Object.values(R.hidden).reduce((n, h) => n + (h.items || []).filter((i) => i.hard).length, 0);
R.challenge = { items: hardItems.map((i) => ({ id: i.id, score: i.score })), points: Math.round((hardItems.reduce((s, i) => s + i.score, 0) / (allHard || 1)) * 5 * 100) / 100 };

// 3) 런북 · 장애 분석 · ops-ci
const { check: checkRunbook } = require(path.join(root, "scripts/check_runbook.js"));
const rb = checkRunbook(root, {});
R.runbook = { score: rb.score, items: rb.items };
const { score: scoreInc } = require(path.join(root, "scripts/check_incidents.js"));
const keysAll = JSON.parse(fs.readFileSync(path.join(__dirname, "keys/incidents.json"), "utf8"));
const keyIds = argv.includes("--extra-incidents") ? Object.keys(keysAll) : ["INC-1", "INC-2", "INC-3"];
const keys = Object.fromEntries(keyIds.map((k) => [k, keysAll[k]]));
let findings = [];
try { findings = JSON.parse(fs.readFileSync(path.join(root, "docs/incident_findings.json"), "utf8")); } catch { notes.push("docs/incident_findings.json 을 읽지 못함"); }
const inc = scoreInc(findings, keys);
R.incidents = inc;
const incPts = inc.reduce((s, x) => s + x.pts, 0), incMax = keyIds.length * 10;
const runCi = (extra) => spawnSync(process.execPath, ["scripts/ops-ci.js", ...extra], { cwd: root, encoding: "utf8", timeout: 120000 });
const own = runCi([]), weak = runCi(["--dir", "ai_ops"]);
R.opsCi = { passesOnOwn: own.status === 0, failsOnWeak: weak.status !== 0 };
R.score.D_incidents = Math.round((incPts / incMax) * 8 * 100) / 100;
R.score.D_runbook = Math.round(rb.score * 4 * 100) / 100;
R.score.D_opsci = R.opsCi.passesOnOwn && R.opsCi.failsOnWeak ? 3 : 0;
R.score.D_total = Math.round((R.score.D_incidents + R.score.D_runbook + R.score.D_opsci) * 100) / 100;
R.score.autoTotal = Math.round((R.score.A_total + R.score.D_total) * 100) / 100;
fs.rmSync(root, { recursive: true, force: true });

if (asJson) { console.log(JSON.stringify(R, null, 2)); process.exit(0); }
const mark = (s) => (s >= 0.999 ? "✔" : s > 0 ? "△" : "✘");
console.log(`\n학생 폴더: ${R.student}`);
notes.forEach((n) => console.log("※ " + n));
for (const k of Object.keys(KEYS)) {
  const h = R.hidden[k];
  console.log(`\n[A. ${KEYS[k]}] 숨은 시나리오 ${(h.score * 100).toFixed(0)}% → ${R.score["A_" + k]}/10점   (공개 시나리오 ${(R.public[k].score * 100).toFixed(0)}%)` + (h.error ? `  ! ${h.error}` : ""));
  for (const i of h.items || []) if (i.score < 0.999) console.log(`   ${mark(i.score)} ${i.id} ${i.title} — ${i.detail}${i.hard ? "  [도전]" : ""}`);
}
console.log(`\n[A 합계] ${R.score.A_total}/40점    [도전 가산] +${R.challenge.points}/5점`);
console.log(`\n[D. 운영 자동화 15점]`);
for (const x of R.incidents) console.log(`   장애 분석 ${x.id}: ${x.pts}/10 ${x.notes.length ? "— " + x.notes.join("; ") : ""}`);
console.log(`   → 장애 분석 ${R.score.D_incidents}/8점`);
console.log(`   런북 완결성 ${(rb.score * 100).toFixed(0)}% → ${R.score.D_runbook}/4점` + (rb.items.filter((i) => !i.ok).length ? "  (부족: " + rb.items.filter((i) => !i.ok).map((i) => i.rule).join(", ") + ")" : ""));
console.log(`   ops-ci: 본인 산출물로 통과 ${R.opsCi.passesOnOwn ? "○" : "×"} · AI 산출물로 실패 ${R.opsCi.failsOnWeak ? "○" : "×"} → ${R.score.D_opsci}/3점`);
console.log(`\n자동 채점 합계(A + D, 도전 제외): ${R.score.autoTotal}/55점`);
console.log("※ B(운영 설계) · C(AI 산출물 리뷰) · E(프로세스·보고·발표)는 문서와 발표로 직접 채점하세요.\n");
