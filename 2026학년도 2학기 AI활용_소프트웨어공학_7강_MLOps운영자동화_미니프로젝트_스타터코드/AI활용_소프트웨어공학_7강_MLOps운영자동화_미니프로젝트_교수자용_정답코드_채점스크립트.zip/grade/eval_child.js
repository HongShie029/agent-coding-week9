// 자식 프로세스에서 한 영역만 평가해 JSON 으로 출력한다. (학생 코드가 무한 루프여도 채점기는 멈추지 않게 하려는 장치)
// 사용: node grade/eval_child.js <프로젝트루트> <pipeline|alerts|policy|rollout> <hidden|public> [dir]
const path = require("path");
const [root, key, set, dir] = process.argv.slice(2);
const { runAll, loadPublicSets } = require(path.join(root, "sim/eval"));
const sets = set === "hidden" ? require("./hidden/sets") : loadPublicSets(root);
const r = runAll(root, { dir: dir && dir !== "-" ? dir : null, sets, only: [key] });
process.stdout.write(JSON.stringify(r[key]));
