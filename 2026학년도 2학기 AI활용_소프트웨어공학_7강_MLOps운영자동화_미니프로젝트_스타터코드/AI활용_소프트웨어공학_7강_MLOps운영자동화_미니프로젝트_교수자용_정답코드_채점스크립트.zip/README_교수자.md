# 7강 AI 기반 MLOps 및 운영자동화 미니 프로젝트 — 교수자용 패키지 (비공개)

학생에게 배포하지 마세요. 숨은 시나리오 · 정답 키 · 모범 답안이 들어 있습니다. (시나리오 · 서비스 · 숫자는 수업용 가상 예시입니다.)

## 구성
| 경로 | 설명 |
|---|---|
| `solution/` | 모범 답안 프로젝트 전체(스타터와 같은 구조). 공개 · 숨은 시나리오 모두 만점 |
| `solution/{pipeline,monitoring,mlops,deploy}` | 모범 게이트 · 알림 규칙 · 정책 · 롤아웃 판단 |
| `solution/ops/runbook.json`, `solution/scripts/ops-ci.js`, `solution/docs/incident_findings.json` | 모범 런북 · 운영 게이트(기준 85%/런북 100%) · 장애 분석 정답 예시 |
| `grade/grade.js` | 자동 채점 보조 (A 숨은 시나리오 40 · 도전 5 · D 장애 분석 8 + 런북 4 + ops-ci 3) |
| `grade/hidden/sets.js` | 숨은 시나리오: 알림 12 · 드리프트 8 · 롤아웃 11 · 게이트 28 · 승격 22 |
| `grade/hidden/{changes,cases}.json` | 숨은 변경 매니페스트 · 승격 사례 |
| `grade/keys/incidents.json` | 장애 분석 정답 키(INC-1~5): 근본 원인 · 원인 변경 · 최초 시각 · 핵심/미끼 로그 ID · 필요한 조치 |
| `grade/eval_child.js` | 영역별 평가를 자식 프로세스(시간 제한)로 실행 — 학생 코드가 무한 루프여도 채점기는 멈추지 않음 |
| `grade/gen_incidents.js` | 인시던트 번들 생성기(5종, 시드로 변형 가능) |
| `incidents_extra/INC-4, INC-5` | 학생에게 나눠 주지 않은 추가 번들(자원 누수 · 코드 회귀). 시험용/재사용 |

## 사용법 (Node.js 20 이상, 외부 패키지 없음)
```bash
# 1) 모범 답안 확인
cd solution && node scripts/eval.js all        # 공개 40/40
cd .. && node grade/grade.js solution          # 숨은 시나리오 포함 55/55 (+5)

# 2) 학생 제출물 채점 (원본 폴더는 수정하지 않음)
node grade/grade.js /path/to/team_project
node grade/grade.js /path/to/team_project --json > team1.json
node grade/grade.js /path/to/team_project --extra-incidents   # INC-4·5 까지 채점(학생이 제출한 경우)
```
`grade.js` 는 임시 폴더에 복사한 뒤 `sim/ lib/ src/ config/ ai_ops/ incidents/ changes/ scripts/(ops-ci.js 제외)` 를 원본으로 복원합니다(변경 흔적은 `※` 로 표시). 그 뒤 숨은 시나리오로 4개 영역을 평가하고, 런북 · 장애 분석 · ops-ci 를 점검합니다. 한 팀 약 1초~수 초.

## 참고 수치
| 산출물 | 공개 시나리오 | 숨은 시나리오 |
|---|---|---|
| 모범 답안 | 40/40 | 40/40 (+도전 5) |
| AI 가 만든 산출물(`ai_ops/`를 학생 파일 자리에 넣은 경우) | 17.1/40 (게이트 41% · 알림 71% · 정책 19% · 롤아웃 41%) | 13.8/40 (33% · 48% · 23% · 33%) |
| 빈 템플릿(예시 게이트 1개) | 4.1/40 | 2.4/40 |

점수는 "탐지율(문제를 잡는 힘)"과 "정상 통과율"의 기하평균이라 아무것도 안 하거나 모든 것을 막는 구현은 0점입니다.

## 유의
- 배점(A40/B15/C15/D15/E15/+5)은 제안입니다. 수업 사정에 맞게 조정하세요.
- 장애 분석 정답 키는 시드 5로 생성한 번들에 대한 것입니다. `gen_incidents.js` 의 시드를 바꾸면 로그 ID 가 달라지므로, 다른 번들로 시험하려면 키도 함께 다시 생성해야 합니다(생성기는 키를 출력합니다).
- 학생이 AI 로 알림 규칙을 만들 때 시뮬레이터 코드를 읽고 숫자를 맞추는 것을 AGENTS.md 의 규칙 1로 막고 있으나, 완전히 막을 수는 없습니다. 숨은 시나리오가 이를 걸러 냅니다.
- 학생 환경이 Node 18 이하이면 일부 문법이 동작하지 않을 수 있습니다.
