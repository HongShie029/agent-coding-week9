// [모범 답안] MLOps 정책 — 드리프트 감지 · 재학습 결정 · 승격 판단
const { psi } = require("../lib/ops");

const MIN_VOLUME = 1000;          // 하루 요청이 이보다 적으면 통계를 믿지 않는다
const PSI_DRIFT = 0.1;            // PSI 0.1 이상이 이틀 연속이면 분포 변화
const NULL_MAX = 0.05, ZERO_PRICE_MAX = 0.20; // 데이터 품질 규칙(계약서 4.2)
const COOLDOWN_DAYS = 7;

function detectDrift(history, ctx) {
  const today = history[history.length - 1];
  if (today.volume < MIN_VOLUME) return { drift: false, kind: "none", reason: "표본 부족" };
  if (today.nullRate >= NULL_MAX || today.priceBins[0] >= ZERO_PRICE_MAX) return { drift: true, kind: "data_quality", reason: "결측/0원 가격 비중 이상" };
  const score = (s) => Math.max(psi(ctx.reference.catBins, s.catBins), psi(ctx.reference.priceBins, s.priceBins));
  const valid = history.filter((s) => s.volume >= MIN_VOLUME);
  const recent = valid.slice(-2);
  if (recent.length === 2 && recent.every((s) => s.nullRate < NULL_MAX && score(s) >= PSI_DRIFT)) return { drift: true, kind: "covariate", reason: "PSI 이틀 연속 기준 초과" };
  return { drift: false, kind: "none" };
}

function retrainDecision({ drift, today, lastRetrainDay }) {
  if (!drift || !drift.drift) return "hold";
  if (drift.kind === "data_quality") return "fix_data";
  if (drift.kind === "covariate") return today - lastRetrainDay >= COOLDOWN_DAYS ? "retrain" : "hold";
  return "hold";
}

function shouldPromote(c, ch) {
  const no = (code, reason) => ({ promote: false, code, reason });
  if (c.evalSet.size < 5000) return no("EVAL_TOO_SMALL", "평가 데이터 5000건 미만");
  if (c.evalSet.overlapWithTrain > 0) return no("LEAKAGE", "학습·평가 데이터 중복");
  if (c.trainedOn.nullRate > 0.02) return no("BAD_TRAIN_DATA", "학습 데이터 결측 2% 초과");
  if (!(c.ci95[0] > ch.hitRatePct)) return no("NOT_SIGNIFICANT", "개선이 통계적으로 확실하지 않음");
  for (const seg of Object.keys(ch.segments || {})) {
    if (c.segments[seg].hitRatePct < ch.segments[seg].hitRatePct - 2.0) return no("SEGMENT_REGRESSION", seg + " 구간 성능 하락");
  }
  if (c.latencyMs > 120 || c.latencyMs > 1.2 * ch.latencyMs) return no("LATENCY", "응답 시간 초과");
  return { promote: true, code: "OK", reason: "모든 승격 기준 충족" };
}
module.exports = { detectDrift, retrainDecision, shouldPromote };
