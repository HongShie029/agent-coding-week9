#!/usr/bin/env node
// [모범 답안] 운영 품질 게이트
const path = require("path");
const { runAll } = require("../sim/eval");
const { check } = require("./check_runbook");

// 근거: AI 산출물(ai_ops)의 공개 시나리오 점수는 파이프라인 50% · 알림 70% · 정책 21% · 롤아웃 40% 였다.
//       우리 산출물은 모두 100% 이므로, 숨은 시나리오에서의 일반화 여유와 정책 변경 시의 탐지력을 고려해
//       각 영역 85% 이상을 요구한다. 런북은 알림 규칙마다 빠짐없이 있어야 하므로 100%.
const THRESHOLDS = { pipeline: 0.85, alerts: 0.85, policy: 0.85, rollout: 0.85, runbook: 1.0 };

const root = path.resolve(__dirname, "..");
const di = process.argv.indexOf("--dir"); const dir = di >= 0 ? process.argv[di + 1] : null;
const res = runAll(root, { dir });
const rb = check(root, { dir });
const results = [];
const step = (name, value, min) => { const ok = value >= min; results.push(ok); console.log(`${ok ? "✔" : "✘"} ${name} — ${(value * 100).toFixed(0)}% (기준 ${(min * 100).toFixed(0)}% 이상)`); };
step("파이프라인 게이트", res.pipeline.score, THRESHOLDS.pipeline);
step("알림 규칙", res.alerts.score, THRESHOLDS.alerts);
step("MLOps 정책", res.policy.score, THRESHOLDS.policy);
step("점진 배포", res.rollout.score, THRESHOLDS.rollout);
step("런북 완결성", rb.score, THRESHOLDS.runbook);
const failed = results.some((r) => !r);
console.log(failed ? "\nOPS-CI 실패" : "\nOPS-CI 통과");
process.exit(failed ? 1 : 0);
