// [모범 답안] 카나리 롤아웃 판단 — 카나리를 같은 시각의 기존 버전(baseline)과 비교한다
const ops = require("../lib/ops");
const rate = (s, n, d) => (s.requests >= 0 && s[d] ? s[n] / s[d] : 0);
const pooled = (w, n, d) => ops.ratio(w, n, d);
const median = (a) => ops.percentile(a, 50);

function decide({ canary, baseline, minuteInStep, trafficPct }) {
  const m = canary.length;
  const roll = (reason) => ({ action: "rollback", reason });
  // 1) 오류: 최근 3분 연속으로 카나리가 기존보다 2%p 이상 높다 → 즉시 롤백
  if (m >= 3) {
    const bRate = pooled(baseline.slice(-8), "errors", "requests");
    const bad3 = canary.slice(-3).every((s) => s.requests > 0 && s.errors / s.requests > bRate + 0.02);
    if (bad3) return roll("오류율 급등(3분 연속)");
  }
  // 2) 오류: 작은 증가도 표본이 모이면 잡는다(최근 8분 통계 + 최근 4분에도 여전히 높음)
  if (m >= 8) {
    const c8 = canary.slice(-8), b8 = baseline.slice(-8), c4 = canary.slice(-4), b4 = baseline.slice(-4);
    const nc = ops.sum(c8, "requests"), nb = ops.sum(b8, "requests");
    const pc = pooled(c8, "errors", "requests"), pb = pooled(b8, "errors", "requests");
    const p = (ops.sum(c8, "errors") + ops.sum(b8, "errors")) / (nc + nb);
    const z = (pc - pb) / Math.sqrt(Math.max(1e-9, p * (1 - p) * (1 / nc + 1 / nb)));
    const above = c8.filter((s) => s.requests > 0 && s.errors / s.requests > pb).length;   // 8분 중 몇 분이 기존보다 높았나(지속성)
    if (z > 4 && above >= 6 && pc - pb >= 0.008 && pooled(c4, "errors", "requests") - pooled(b4, "errors", "requests") >= 0.008) return roll("오류율이 기존보다 유의하게 높음");
  }
  // 3) 지연: 최근 5분 p95 중앙값이 기존의 1.3배 초과
  if (m >= 5) {
    const cm = median(canary.slice(-5).map((s) => s.p95Ms)), bm = median(baseline.slice(-5).map((s) => s.p95Ms));
    if (cm > bm * 1.3) return roll("p95 지연 1.3배 초과");
  }
  // 4) 결제 실패율: 카나리 결제 시도 15건 이상이고 기존보다 10%p 이상 높음
  { const c = canary.slice(-12), b = baseline.slice(-12);
    if (ops.sum(c, "paymentAttempts") >= 15 && pooled(c, "paymentFails", "paymentAttempts") - pooled(b, "paymentFails", "paymentAttempts") > 0.10) return roll("결제 실패율 급등"); }
  // 5) 추천 품질(조용한 장애): 노출 1500건 이상에서 클릭률이 기존의 80% 미만
  { const c = canary.slice(-12), b = baseline.slice(-12);
    const nc = ops.sum(c, "recImpr"), nb = ops.sum(b, "recImpr");
    if (nc >= 1500 && nb > 0) {
      const pc = pooled(c, "recClicks", "recImpr"), pb = pooled(b, "recClicks", "recImpr");
      const p = (ops.sum(c, "recClicks") + ops.sum(b, "recClicks")) / (nc + nb);
      const z = (pb - pc) / Math.sqrt(Math.max(1e-12, p * (1 - p) * (1 / nc + 1 / nb)));
      if (z > 4 && pc < 0.85 * pb) return roll("추천 클릭률 하락(통계적으로 유의)");
    } }
  // 승격: 최소 10분 지켜보고, 기존 버전도 정상일 때만(외부 장애 중에는 판단 보류)
  const baseErr = pooled(baseline.slice(-3), "errors", "requests");
  const baseP95 = median(baseline.slice(-3).map((s) => s.p95Ms));
  if (baseErr > 0.02 || baseP95 > 800) return { action: "hold", reason: "기존 버전도 비정상(환경 문제) — 판단 보류" };
  if (minuteInStep >= 10) return { action: "promote", reason: "10분 관찰 통과" };
  return { action: "hold", reason: "관찰 중" };
}
module.exports = { decide };
