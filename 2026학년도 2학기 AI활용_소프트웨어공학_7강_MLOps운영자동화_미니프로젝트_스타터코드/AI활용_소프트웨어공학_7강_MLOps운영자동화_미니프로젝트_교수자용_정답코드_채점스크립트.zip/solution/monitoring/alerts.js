// [모범 답안] 알림 규칙 — 지속성(몇 분 동안 계속인가)과 평소 대비(상대 비교)를 쓴다
const ops = require("../lib/ops");
const errRate = (s) => (s.requests ? s.errors / s.requests : 0);

module.exports = { rules: [
  { id: "error-sustained", severity: "page", runbook: "RB-ERR-SPIKE",
    evaluate: (w) => ops.allLast(w, 4, (s) => s.requests >= 50 && errRate(s) > 0.03) },
  { id: "error-slow-burn", severity: "page", runbook: "RB-ERR-SLOW",
    evaluate: (w) => w.length >= 15 && ops.last(w, 15).filter((s) => s.requests >= 50 && errRate(s) > 0.012).length >= 12 },
  { id: "latency-high", severity: "page", runbook: "RB-LATENCY",
    evaluate: (w) => ops.allLast(w, 3, (s) => s.p95Ms > 650) },
  { id: "traffic-drop", severity: "page", runbook: "RB-TRAFFIC",
    evaluate: (w) => ops.allLast(w, 5, (s) => s.requests / ops.expected(s.minuteOfDay) < 0.6) },
  { id: "payment-fail-rate", severity: "page", runbook: "RB-PAYMENT",
    evaluate: (w) => { const x = ops.last(w, 10); return ops.sum(x, "paymentAttempts") >= 60 && ops.ratio(x, "paymentFails", "paymentAttempts") > 0.10; } },
  { id: "rec-ctr-drop", severity: "ticket", runbook: "RB-REC-QUALITY",
    evaluate: (w) => { const x = ops.last(w, 30); return ops.sum(x, "recImpr") >= 3000 && ops.ratio(x, "recClicks", "recImpr") < 0.06; } },
] };
