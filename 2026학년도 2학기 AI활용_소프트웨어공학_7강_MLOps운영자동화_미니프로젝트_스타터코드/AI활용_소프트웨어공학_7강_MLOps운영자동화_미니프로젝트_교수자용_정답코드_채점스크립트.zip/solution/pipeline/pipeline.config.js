// [모범 답안] 파이프라인 게이트
const { shouldPromote } = require("../mlops/policy");
const ok = { pass: true };
const fail = (code, reason) => ({ pass: false, code, reason });
const touchesCode = (c) => c.touches.some((t) => t === "src" || t === "model" || t === "config" || t === "infra");
const docsOnly = (c) => c.touches.every((t) => t === "docs");

module.exports = {
  stages: [
    { name: "validate", gates: [
      { id: "secret-scan", check: (c) => (c.diff.secrets || []).some((s) => s.confidence === "high") ? fail("SECRET_LEAK", "비밀 값 노출") : ok },
      { id: "migration-safety", check: (c) => c.migration && c.migration.destructive && !c.migration.reversible ? fail("DESTRUCTIVE_MIGRATION", "되돌릴 수 없는 삭제") : ok },
    ] },
    { name: "test", gates: [
      { id: "tests-exist", check: (c) => c.touches.includes("src") && c.tests.total === 0 ? fail("TEST_MISSING", "소스 변경인데 테스트 없음") : ok },
      { id: "tests-pass", check: (c) => c.tests.failed > 0 ? fail("TEST_FAIL", "실패 테스트") : ok },
      { id: "tests-skipped", check: (c) => c.tests.total > 0 && c.tests.skipped / c.tests.total > 0.05 ? fail("TEST_SKIPPED_MANY", "건너뛴 테스트 5% 초과") : ok },
      { id: "tests-flaky", check: (c) => c.tests.retries >= 3 ? fail("TEST_FLAKY", "재시도 3회 이상") : ok },
      { id: "coverage", check: (c) => !docsOnly(c) && c.tests.coveragePct - c.tests.coverageBasePct < -3 ? fail("COVERAGE_DROP", "커버리지 3%p 초과 하락") : ok },
      { id: "mutation", check: (c) => c.touches.includes("src") && !(c.tests.mutationScore >= 70) ? fail("MUTATION_LOW", "변이 점수 70 미만 또는 미측정") : ok },
    ] },
    { name: "model-eval", gates: [
      { id: "promotion-policy", check: (c) => { if (!c.model) return ok; const r = shouldPromote(c.model.candidate, c.model.champion); return r.promote ? ok : fail(r.code, r.reason); } },
    ] },
    { name: "build", gates: [
      { id: "build-ok", check: (c) => !docsOnly(c) && c.build && c.build.ok === false ? fail("BUILD_FAIL", "빌드 실패") : ok },
      { id: "vulnerability", check: (c) => (c.build && c.build.vulns || []).some((v) => v.severity === "critical" && v.scope === "runtime") ? fail("VULN_CRITICAL", "런타임 치명 취약점") : ok },
      { id: "image-size", check: (c) => c.build && c.build.baseSizeMB && c.build.sizeMB / c.build.baseSizeMB > 1.3 ? fail("SIZE_BLOAT", "이미지 30% 초과 증가") : ok },
    ] },
    { name: "staging", gates: [
      { id: "smoke", check: (c) => { if (docsOnly(c)) return ok; const s = c.staging; return !s || s.smokePassed < s.smokeTotal ? fail("SMOKE_FAIL", "스모크 테스트 미통과/미실시") : ok; } },
    ] },
  ],
};
